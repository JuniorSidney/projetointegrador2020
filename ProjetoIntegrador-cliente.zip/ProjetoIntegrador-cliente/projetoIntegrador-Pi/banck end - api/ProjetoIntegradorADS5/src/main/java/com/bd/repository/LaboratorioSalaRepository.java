package com.bd.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bd.model.LaboratorioSala;


public interface LaboratorioSalaRepository extends JpaRepository<LaboratorioSala, Long>{


}
