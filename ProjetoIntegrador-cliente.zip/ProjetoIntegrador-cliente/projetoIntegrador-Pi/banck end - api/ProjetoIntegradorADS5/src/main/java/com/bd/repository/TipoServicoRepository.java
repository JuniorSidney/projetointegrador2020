package com.bd.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.bd.model.TipoServico;



public interface TipoServicoRepository extends JpaRepository<TipoServico, Long>{


}
