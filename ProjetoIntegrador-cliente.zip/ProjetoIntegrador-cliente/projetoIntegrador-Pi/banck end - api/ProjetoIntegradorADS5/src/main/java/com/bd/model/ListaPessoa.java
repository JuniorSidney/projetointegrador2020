package com.bd.model;

public interface ListaPessoa {
	public Long getId();
	public String getNome();
}
