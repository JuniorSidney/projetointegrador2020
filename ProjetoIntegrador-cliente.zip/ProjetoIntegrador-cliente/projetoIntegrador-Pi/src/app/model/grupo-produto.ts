export class GrupoProduto {
    id: number;
    descricao: string;
}