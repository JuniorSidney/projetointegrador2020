export class LaboratorioSala {
    id: number;
    nome: string;
}
