export class Usuario {
login: String;
senha : String;
}