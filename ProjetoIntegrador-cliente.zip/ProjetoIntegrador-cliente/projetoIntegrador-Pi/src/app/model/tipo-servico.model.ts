export class TipoServico {
    id: number;
    descricao: string;
}
