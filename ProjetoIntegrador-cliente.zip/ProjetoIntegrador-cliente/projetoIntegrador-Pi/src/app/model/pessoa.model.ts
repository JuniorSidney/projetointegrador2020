export class Pessoa {
    id: number;
    nome: string;
    pes_cpf_cnpj: string;
    pes_telefone: string;
    pes_email: string;
    pes_funcao: string;
    pes_login: string;
    pes_senha: string;
    pes_perfil: string;

}
