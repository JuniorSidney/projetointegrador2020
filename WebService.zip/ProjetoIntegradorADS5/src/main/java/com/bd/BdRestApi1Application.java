package com.bd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BdRestApi1Application {



	public static void main(String[] args) {
		SpringApplication.run(BdRestApi1Application.class, args);
		
	
	    
	}

}
